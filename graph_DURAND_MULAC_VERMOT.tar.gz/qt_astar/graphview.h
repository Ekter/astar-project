#ifndef GRAPHVIEW_H
#define GRAPHVIEW_H


class GraphView  : public View
{
public:
    GraphView();
};

#endif // GRAPHVIEW_H
