#include "graph.h"

Graph:: Graph()
{
    //vertices.push_back(Vertex(70,30,1234));


}

void Graph::addVertexToGraph(const Vertex& vertex){

}


